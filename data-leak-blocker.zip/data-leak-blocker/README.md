# Data Leak Blocker — Installation Guide

## Quick Install (3 steps)

### Step 1: Copy the skill folder

Copy `data-leak-blocker/` into your project's `.claude/skills/` directory:

```
your-project/
  .claude/
    skills/
      data-leak-blocker/       ← copy this entire folder
        SKILL.md
        README.md
        hooks/
          block-read-dataleak.ps1
          block-read-dataleak.sh
```

### Step 2: Edit the hook for your environment

Open **`hooks/block-read-dataleak.ps1`** and change line 44 (the Python path in the error message):

```powershell
# Line 44 — change this:
Use: D:/dev/envs/py314/python.exe

# To your own Python path, e.g.:
Use: python3
# or:
Use: C:/Users/yourname/.venv/Scripts/python.exe
```

Also change line 29 (debug log path) if you want:

```powershell
# Line 29:
"$triggerTime | ..." | Out-File -Append -Encoding UTF8 "D:\claude-main\.claude\hooks\hook-debug.log"

# Change to your project path, or delete line 28-30 if you don't need debug logging.
```

For **Linux/macOS**: edit `hooks/block-read-dataleak.sh` line 30 (Python path in heredoc) instead.

### Step 3: Register the hook in settings

Add this to your project's **`.claude/settings.local.json`**:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Read",
        "hooks": [
          {
            "type": "command",
            "command": "powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"${CLAUDE_PROJECT_DIR}/.claude/skills/data-leak-blocker/hooks/block-read-dataleak.ps1\""
          }
        ]
      }
    ]
  }
}
```

**For Linux/macOS**, use the bash version instead:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Read",
        "hooks": [
          {
            "type": "command",
            "command": "bash ${CLAUDE_PROJECT_DIR}/.claude/skills/data-leak-blocker/hooks/block-read-dataleak.sh"
          }
        ]
      }
    ]
  }
}
```

## Verify Installation

Restart Claude Code and try reading a CSV file. You should see:

```
[SYSTEM BLOCK -- PreToolUse Hook] Read was called on a data file.
This tool call has been REJECTED to prevent token overflow.

CORRECT NEXT STEP: Write a Python inspection script...
```

## Customization

### Add/Remove Blocked Extensions

In the ps1 file, find line 33:
```powershell
$blockedPattern = '\.(csv|dta|xlsx|...)$'
```

Add or remove extensions as needed. The pattern is a regex alternation — just add `|newext` inside the parentheses.

### Disable for a Session

Delete or rename the hook entry in `settings.local.json`:
```bash
mv .claude/settings.local.json .claude/settings.local.json.disabled
```

### Silent Mode (no stderr message)

Change `exit 2` to `exit 0` in the hook script — the Read call will be silently allowed. NOT recommended.

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Hook doesn't fire | Check PowerShell execution policy: `Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass` |
| "ConvertFrom-Json" error | PowerShell version too old, upgrade to 5.1+ |
| Hook fires but Read still works | Check exit code — must be `exit 2` (not `exit 0` or `exit 1`) |
| Debug: is hook even called? | Enable debug logging (line 28-30 in ps1), check `hook-debug.log` |

## License

MIT — share freely, modify as you like.
